fx_version 'cerulean'
game 'gta5'

-- Add this line to specify Lua 5.4
lua54 'yes'

-- Script details
name 'point'
author 'Crazy Eyes Studio'
version '1.0.0'

-- Client scripts
client_scripts {
    'client.lua'
}